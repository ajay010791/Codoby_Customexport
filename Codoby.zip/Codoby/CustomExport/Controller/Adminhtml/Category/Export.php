<?php
namespace Exinent\CustomExport\Controller\Adminhtml\Category;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\File\Csv;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory as CategoryCollectionFactory;
use Magento\Cms\Model\BlockFactory;
use Magento\Framework\App\Response\Http\FileFactory;

class Export extends Action
{
    protected $categoryCollectionFactory;
    protected $csvProcessor;
    protected $directoryList;
    protected $blockFactory;
    protected $fileFactory;

    public function __construct(
        Context $context,
        CategoryCollectionFactory $categoryCollectionFactory,
        Csv $csvProcessor,
        DirectoryList $directoryList,
        BlockFactory $blockFactory,
        FileFactory $fileFactory
    ) {
        parent::__construct($context);
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->csvProcessor = $csvProcessor;
        $this->directoryList = $directoryList;
        $this->blockFactory = $blockFactory;
        $this->fileFactory = $fileFactory;
    }

    public function execute()
    {
        // Ensure user is logged in and authorized
        if (!$this->_authorization->isAllowed('Exinent_CustomExport::category_export')) {
            $this->messageManager->addErrorMessage(__('You are not authorized to export categories.'));
            $resultRedirect = $this->resultRedirectFactory->create();
            $resultRedirect->setPath('adminhtml/*/');
            return $resultRedirect;
        }

        $fileName = 'categories_with_blocks.csv';
        $varDirectory = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $csvFilePath = $varDirectory . '/' . $fileName;

        /** @var \Magento\Catalog\Model\ResourceModel\Category\Collection $collection */
        $collection = $this->categoryCollectionFactory->create();
        $collection->addAttributeToSelect('*'); // Select all category attributes

        // Prepare CSV headers dynamically from the first item
        $csvData = [];
        $csvHeader = array_keys($collection->getFirstItem()->getData());
        $csvHeader[] = 'Static Block Identifier';
        $csvHeader[] = 'Static Block Content';
        $csvData[] = $csvHeader;

        // Prepare CSV data
        foreach ($collection as $category) {
            $row = [];
            foreach ($csvHeader as $attribute) {
                if ($attribute == 'Static Block Identifier') {
                    $staticBlockId = $category->getData('landing_page'); // Assuming 'landing_page' is the attribute for the static block
                    if ($staticBlockId) {
                        $block = $this->blockFactory->create()->load($staticBlockId);
                        $row[] = $block->getIdentifier();
                    } else {
                        $row[] = '';
                    }
                } elseif ($attribute == 'Static Block Content') {
                    $staticBlockId = $category->getData('landing_page'); // Assuming 'landing_page' is the attribute for the static block
                    if ($staticBlockId) {
                        $block = $this->blockFactory->create()->load($staticBlockId);
                        $row[] = $block->getContent();
                    } else {
                        $row[] = '';
                    }
                } else {
                    $row[] = $category->getData($attribute);
                }
            }
            $csvData[] = $row;
        }

        // Save the CSV file
        $this->csvProcessor->setEnclosure('"')->setDelimiter(',')->saveData($csvFilePath, $csvData);

        // Download the CSV file
        return $this->fileFactory->create(
            $fileName,
            [
                'type' => 'filename',
                'value' => $csvFilePath,
                'rm' => true // Automatically remove file after download
            ],
            DirectoryList::VAR_DIR
        );
    }
}
