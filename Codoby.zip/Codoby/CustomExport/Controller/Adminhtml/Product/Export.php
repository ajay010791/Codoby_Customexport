<?php
namespace Exinent\CustomExport\Controller\Adminhtml\Product;

use Magento\Backend\App\Action;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\File\Csv;
use Magento\Eav\Model\Config as EavConfig;

class Export extends Action
{
    protected $productCollectionFactory;
    protected $directoryList;
    protected $csvProcessor;
    protected $eavConfig;

    public function __construct(
        Action\Context $context,
        CollectionFactory $productCollectionFactory,
        Csv $csvProcessor,
        DirectoryList $directoryList,
        EavConfig $eavConfig
    ) {
        parent::__construct($context);
        $this->productCollectionFactory = $productCollectionFactory;
        $this->directoryList = $directoryList;
        $this->csvProcessor = $csvProcessor;
        $this->eavConfig = $eavConfig;
    }

    public function execute()
    {
        $fileName = 'all_product_data.csv';
        $varDirectory = $this->directoryList->getPath(DirectoryList::VAR_DIR);
        $csvFilePath = $varDirectory . '/' . $fileName;

        /** @var \Magento\Catalog\Model\ResourceModel\Product\Collection $collection */
        $collection = $this->productCollectionFactory->create();
        $collection->addAttributeToSelect('*'); // Select all attributes

        // Get all custom attribute codes
        $entityType = $this->eavConfig->getEntityType(\Magento\Catalog\Model\Product::ENTITY);
        $attributeCollection = $this->_objectManager->create(\Magento\Catalog\Model\ResourceModel\Product\Attribute\Collection::class)
            ->addFieldToFilter('entity_type_id', $entityType->getId())
            ->addFieldToFilter('is_user_defined', 1);

        $customAttributes = $attributeCollection->getColumnValues('attribute_code');

        // Prepare CSV header
        $csvHeader = $collection->getFirstItem()->getData();
        $csvHeaderKeys = array_keys($csvHeader);
        $csvHeader = array_merge($csvHeaderKeys, $customAttributes);
        $csvData = [$csvHeader];

        // Prepare CSV data
        foreach ($collection as $product) {
            $row = [];

            // Add default attribute values
            foreach ($csvHeaderKeys as $attribute) {
                $row[] = $product->getData($attribute);
            }

            // Add custom attribute values
            foreach ($customAttributes as $attribute) {
                $row[] = $product->getData($attribute);
            }

            $csvData[] = $row;
        }

        // Save CSV file
        $this->csvProcessor->setEnclosure('"')->setDelimiter(',')->saveData($csvFilePath, $csvData);

        // Prepare file download
        $fileContent = file_get_contents($csvFilePath);
        $this->_response->setHeader('Content-type', 'application/octet-stream');
        $this->_response->setHeader('Content-Disposition', 'attachment; filename=' . $fileName);
        $this->_response->setBody($fileContent);

        return $this->_response;
    }
}
